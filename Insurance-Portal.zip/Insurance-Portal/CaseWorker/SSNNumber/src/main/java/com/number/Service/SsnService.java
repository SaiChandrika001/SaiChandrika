package com.number.Service;

import com.number.binding.Request;
import com.number.binding.SsnResponse;


public interface SsnService {
	
	public SsnResponse AddSSn(Request request);

	  public SsnResponse getSsnDetails(Long ssn);

}
