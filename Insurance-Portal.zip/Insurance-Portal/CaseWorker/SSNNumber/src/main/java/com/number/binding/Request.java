package com.number.binding;

import lombok.Data;

@Data
public class Request {
    
    private String stateName;
    private long ssn;
    private String fullName;
  
}
