package com.number.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.number.Service.SsnService;
import com.number.binding.Request;
import com.number.binding.SsnResponse;


@RestController
@RequestMapping("/api")
public class SsnController {
    	@Autowired
    	private SsnService ssnService;
    	
    	
    	@PostMapping("/ssn")
    	public ResponseEntity<SsnResponse> saveSSn(@RequestBody Request request)
    	{
    		
    		SsnResponse addSSn = ssnService.AddSSn(request);
    		
    		return new ResponseEntity<SsnResponse>(addSSn, HttpStatus.CREATED);
    		
    	}
    	@GetMapping("/{ssn}")
        public ResponseEntity<SsnResponse> validateSsn(@PathVariable Long ssn) {
            SsnResponse validateSsn = ssnService.getSsnDetails(ssn);
            return ResponseEntity.ok(validateSsn);
        }

    }


