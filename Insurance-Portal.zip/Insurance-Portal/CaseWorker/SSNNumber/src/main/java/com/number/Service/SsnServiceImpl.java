package com.number.Service;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.number.binding.Request;
import com.number.binding.SsnResponse;
import com.number.entity.SsnNumber;
import com.number.repository.SsnRepository;

@Service
public class SsnServiceImpl implements SsnService {
	
	@Autowired
	private SsnRepository ssnRepo;

	
	@Override
	public SsnResponse AddSSn(Request request) {
		SsnNumber entity =new SsnNumber();
		BeanUtils.copyProperties(request, entity);
		SsnNumber save = ssnRepo.save(entity);
		if(save==null)
		{
		  System.out.println("Not added");
		}
		SsnResponse response =new SsnResponse();
		BeanUtils.copyProperties(save, response);
		return response;
	}


	@Override
	 public SsnResponse getSsnDetails(Long ssn) {
       SsnNumber record = ssnRepo.findBySsn(ssn)
           .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "SSN not found"));

       SsnResponse response = new SsnResponse();
       response.setSsn(record.getSsn());
       response.setFullName(record.getFullName());
       response.setStateName(record.getStateName());

       return response;
   }
}
