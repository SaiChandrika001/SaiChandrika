package com.number.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.number.entity.SsnNumber;

	  @Repository
	  public interface SsnRepository extends JpaRepository<SsnNumber,Long> {
	      
	  	Optional<SsnNumber>findBySsn(Long ssn);
 }
