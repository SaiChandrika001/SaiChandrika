package com.number.binding;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class SsnResponse {

	private Integer id; 
	private String fullName;
	private String stateName;
	private long Ssn;
  
	public SsnResponse() {
		
	}
	
}
