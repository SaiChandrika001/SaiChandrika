package com.number;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SsnNumberApplication {

	public static void main(String[] args) {
		SpringApplication.run(SsnNumberApplication.class, args);
	}

}
