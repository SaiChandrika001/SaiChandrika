package com.sts.admin.Exception;

public class CaseWorkerNotFoundException extends RuntimeException{

    public CaseWorkerNotFoundException(String message) {
        super(message);
    }
}
