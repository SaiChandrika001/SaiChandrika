package com.sts.admin.Exception;

public class DateException  extends RuntimeException{

    public DateException(String message) {
        super(message);
    }
}
