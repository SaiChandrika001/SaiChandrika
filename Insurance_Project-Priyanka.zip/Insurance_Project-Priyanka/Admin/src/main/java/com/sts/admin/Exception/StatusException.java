package com.sts.admin.Exception;

public class StatusException extends RuntimeException {
    public StatusException(String message) {
        super(message);
    }
}
