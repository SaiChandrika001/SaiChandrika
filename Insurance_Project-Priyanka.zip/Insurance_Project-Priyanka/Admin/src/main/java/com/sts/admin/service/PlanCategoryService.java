package com.sts.admin.service;

import com.sts.admin.binding.PlanCateroryBinding;
import com.sts.admin.entity.PlanCategory;


public interface PlanCategoryService {

      PlanCategory savePlanCategory(PlanCateroryBinding cateroryBinding);


}
