package com.support.binding;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SupportRequest {
	private Long userId;
	private String issueType;
	private String description;
	private String priority;
}
