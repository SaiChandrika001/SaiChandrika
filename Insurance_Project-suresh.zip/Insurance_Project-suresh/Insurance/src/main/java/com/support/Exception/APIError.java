package com.support.Exception;

import lombok.Data;

@Data
public class APIError {

    private String code;

    private String message;


}
