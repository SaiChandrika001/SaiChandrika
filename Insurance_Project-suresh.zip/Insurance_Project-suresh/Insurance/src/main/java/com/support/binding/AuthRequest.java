package com.support.binding;

import lombok.Data;

@Data
public class AuthRequest {

    private String userName;

    private String password;


}
