package com.insurance.ed.exception;

public class EligibilityProcessingException extends RuntimeException {

    public EligibilityProcessingException(String message) {
        super(message);
    }
}
