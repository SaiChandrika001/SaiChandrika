package com.insurance.ed;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EligibilityDeterminationApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
