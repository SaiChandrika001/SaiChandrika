package com.insurance.datacollection.binding;

import lombok.Data;

@Data
public class DCCaseRequest {

    private Integer applicationId;

    private Integer planId;
}
