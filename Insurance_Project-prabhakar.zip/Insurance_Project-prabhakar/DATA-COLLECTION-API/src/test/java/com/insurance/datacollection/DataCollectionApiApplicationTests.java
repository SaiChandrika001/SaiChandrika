package com.insurance.datacollection;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataCollectionApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
