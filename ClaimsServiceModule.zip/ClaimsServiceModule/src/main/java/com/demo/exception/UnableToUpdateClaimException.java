package com.demo.exception;

public class UnableToUpdateClaimException extends RuntimeException{

	public UnableToUpdateClaimException(String message) {
		super(message);
	}
}
