package com.demo.exception;

public class UnableToDeleteClaimException extends RuntimeException {
	
	public UnableToDeleteClaimException(String message) {
		super(message);
	}

}
