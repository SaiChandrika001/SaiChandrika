package com.demo.exception;

public class UnableToCreateClaimException extends RuntimeException {
	
	public UnableToCreateClaimException(String message) {
		super(message);
	}

}
