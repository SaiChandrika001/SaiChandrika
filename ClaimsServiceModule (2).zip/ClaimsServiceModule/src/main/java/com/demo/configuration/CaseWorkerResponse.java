package com.demo.configuration;

public class CaseWorkerResponse {

}
