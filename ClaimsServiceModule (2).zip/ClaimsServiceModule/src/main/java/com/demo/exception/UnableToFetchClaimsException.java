package com.demo.exception;

public class UnableToFetchClaimsException extends RuntimeException {
	
	public UnableToFetchClaimsException(String message) {
		super(message);
	}

}
