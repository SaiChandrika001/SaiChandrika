package com.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
//import de.codecentric.boot.admin.server.config.EnableAdminServer;

@SpringBootApplication
//@EnableDiscoveryClient 
@EnableFeignClients("https:localhost:808")   
//@EnableAdminServer
public class ClaimsServiceModule {

    public static void main(String[] args) {
        SpringApplication.run(ClaimsServiceModule.class, args);
    }
}
