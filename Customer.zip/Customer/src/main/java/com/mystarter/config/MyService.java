package com.mystarter.config;

public class MyService {
	
	   public String hello() {
	        return "Hello from My Starter is working!";
	    }

}
