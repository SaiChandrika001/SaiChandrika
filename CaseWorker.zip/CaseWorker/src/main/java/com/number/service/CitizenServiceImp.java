package com.number.service;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.server.ResponseStatusException;

import com.number.binding.CitizenRequest;
import com.number.binding.CitizenResponse;
import com.number.binding.SsnResponse;
import com.number.entity.Citizens;
import com.number.repository.CitizenRepository;

import jakarta.persistence.EntityNotFoundException;
import reactor.core.publisher.Mono;

@Service
public class CitizenServiceImp implements CitizenService{
//  private final CitizenController citizenController;

	
	  @Autowired
	    private WebClient.Builder webClientBuilder;
	
	  @Autowired
	   private CitizenRepository citizenRepo;


//   CitizenServiceImp(CitizenController citizenController) {
//       this.citizenController = citizenController;
//   }
	
	
	@Override
	public CitizenResponse registerCitizen(CitizenRequest request) {
		
		   CitizenResponse response = new CitizenResponse();
		
		   // Check if SSN already exists
		boolean exists = citizenRepo.existsBySsn(request.getSsn());
	    if (exists) {
	      //  CitizenResponse response = new CitizenResponse();
	        response.setStatus("fail");
	        response.setMessage("Citizen already registered with this SSN");
	        return response;
	    }
		
		
		
		  SsnResponse ssnData = null;
		 // Call SSN service
		  try {
        ssnData = webClientBuilder.build()
               .get()
               .uri("http://localhost:9090/ssn/{ssn}", request.getSsn())
               .retrieve()
               .onStatus(status -> status.is4xxClientError(), responses -> {
                   return Mono.error(new RuntimeException("SSN not found in SSN service"));
               })
               .onStatus(status -> status.is5xxServerError(), responses -> {
                   return Mono.error(new RuntimeException("SSN service is currently unavailable"));
               })
               .bodyToMono(SsnResponse.class)
               .block();
		  }
		  catch(RuntimeException e)
		  {
			  throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage(), e);
		  }

       if (ssnData == null) {
           throw new RuntimeException("SSN not found in SSN service");
       }

       Citizens citizen = new Citizens();
       citizen.setSsn(request.getSsn());
       citizen.setFullName(request.getFullName());
       citizen.setStateName(request.getStateName());
       citizen.setPhno(request.getPhno());
       citizen.setEmail(request.getEmail());
       citizen.setGender(request.getGender());
       citizen.setDob(request.getDob());
       citizen.setCreatedBy("SYSTEM");
       citizen.setUpdatedBy("SYSTEM");
       

       citizenRepo.save(citizen);
       response.setCitizen(citizen);
       response.setStatus("SUCCESS");
       response.setMessage("Citizen registered successfully");

       return response;
  
	}
	@Override
	public boolean deleteCitizen(Integer id) {
		 Optional<Citizens> bySsn = citizenRepo.findById(id);
		 
		 if(bySsn.isPresent())
		 {
			 citizenRepo.delete(bySsn.get());
		        return true; // deletion successful
		 }else
		 {
			
			 return false;
		 }
		
		 
	}
	@Override
	public List<CitizenResponse> getAllCitizens() {

	    List<CitizenResponse> listOfResponse = new ArrayList<>();
	    List<Citizens> all = citizenRepo.findAll();

	    for (Citizens citizen : all) {
	        CitizenResponse response = new CitizenResponse();
	        response.setCitizen(citizen);
	        response.setStatus("SUCCESS");
	        response.setMessage("Citizen data fetched successfully");
	        listOfResponse.add(response);
	    }

	    return listOfResponse;
	
   }
	@Override
	public List<CitizenResponse> updateCitizen(CitizenRequest request,Integer id) {
		
		 List<CitizenResponse> responseList = new ArrayList<>();

		    // 1. Find citizen by ID
		    Optional<Citizens> optionalCitizen = citizenRepo.findById(id);

		    if (optionalCitizen.isEmpty()) {
		        // If not found, return a single response indicating failure
		        CitizenResponse response = new CitizenResponse();
		        response.setStatus("FAIL");
		        response.setMessage("Citizen with ID " + id + " not found");
		        responseList.add(response);
		        return responseList;
		    }

		    // 2. Get existing citizen
		    Citizens citizen = optionalCitizen.get();

		    // 3. Update only non-null fields
		    if (request.getFullName() != null) {
		        citizen.setFullName(request.getFullName());
		    }
		    if (request.getStateName() != null) {
		        citizen.setStateName(request.getStateName());
		    }
		    if (request.getPhno() != null) {
		        citizen.setPhno(request.getPhno());
		    }
		    if (request.getEmail() != null) {
		        citizen.setEmail(request.getEmail());
		    }
		    if (request.getGender() != null) {
		        citizen.setGender(request.getGender());
		    }
		    if (request.getDob() != null) {
		        citizen.setDob(request.getDob());
		    }

		    // Optionally, don’t allow SSN changes — but if you do, uncomment this:
		    // if (request.getSsn() != null) {
		    //     citizen.setSsn(request.getSsn());
		    // }

		    citizen.setUpdatedBy("SYSTEM");
		  //  citizen.setUpdateDate(LocalDateTime.now()); // if you have a timestamp field

		    // 4. Save updated citizen
		    citizenRepo.save(citizen);

		    // 5. Return all citizens (same as getAllCitizens)
		    List<Citizens> allCitizens = citizenRepo.findAll();

		    for (Citizens c : allCitizens) {
		        CitizenResponse resp = new CitizenResponse();
		        resp.setCitizen(c);
		        resp.setStatus("SUCCESS");
		        resp.setMessage("Citizen data fetched successfully after update");
		        responseList.add(resp);
		    }

		    return responseList;
	}
}

