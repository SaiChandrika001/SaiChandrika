package com.number.binding;

import lombok.Data;

@Data
public class SsnResponse {

	    private Long ssn;
	    private String fullname;
	    private String statename;
}
